import requests
from bs4 import BeautifulSoup
import re


def main():
    r = requests.get("http://tamilyogi.cafe/category/new-tamil-movies-online/")
    soup = BeautifulSoup(r.content, "html.parser")

    items = soup.find("ul", {"id": "loop"}).find_all("li")
    genre = "Tamil New Movies"
    data = {}
    data[genre] = []

    for item in items:
        if item.text.strip() == "":
            continue

        video = item.find("a")["href"]
        thumb = item.find("img")["src"]
        name = item.find("h2").text

        data[genre].append({"name": name, "video": video, "thumb": thumb, "genre": genre})

    
    v = data[genre][0]

    r = requests.get(v["video"])
    soup = BeautifulSoup(r.content, "html.parser")
    src = soup.select("iframe[src^='http://']")[0]["src"]
    r = requests.get(src)

    m = re.search(r'http:\/\/(.*?)\.m3u8', r.text)
    if m:
        stream = "http://{}.m3u8".format(m.group(1))
    lines = requests.get(stream).text.split("\n")
    minQ = 999999999999
    stream_url = ""
    for line in lines:
        print(line)
        m = re.search(r'BANDWIDTH=([0-9]+)', line.strip())
        if m and line.find("URI=") > -1:
            q = int(m.group(1))
            if q < minQ:
                minQ = q
                stream_url = re.search(r'URI="(.*?)"', line.strip()).group(1)

    print(stream_url)



if __name__ == '__main__':
    main()
